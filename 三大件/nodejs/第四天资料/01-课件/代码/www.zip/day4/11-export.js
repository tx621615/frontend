var name = '武松'
var age = 88
var fn = () => console.log('hello')

export {name, age, fn}