

export default (name) => {
	console.log('测试')
	console.log(name)
}