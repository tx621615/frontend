//引入自定义模块
var b = require('./b'); //注：.js不用写

console.log(b);

b.add()
b.del()