var test = require('itcast-php-teacher2')


console.log(test)
console.log(test.name)
test.say()
