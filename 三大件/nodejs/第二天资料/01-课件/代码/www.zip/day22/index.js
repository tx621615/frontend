var fn = {
	name: 'phpopenfather',
	school: 'php@itcast',
	say: function() {
		console.log('悟空');
	}
}
module.exports = fn